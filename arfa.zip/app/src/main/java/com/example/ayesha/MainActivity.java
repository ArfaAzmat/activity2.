package com.example.ayesha;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private EditText nameEditText;
    private Button saveButton;
    private Button searchButton;
    private ListView nameListView;

    private ArrayList<String> namesList;
    private ArrayAdapter<String> namesAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameEditText = findViewById(R.id.nameEditText);
        saveButton = findViewById(R.id.saveButton);
        searchButton = findViewById(R.id.searchButton);
        nameListView = findViewById(R.id.nameListView);

        namesList = new ArrayList<>();
        namesAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, namesList);
        nameListView.setAdapter(namesAdapter);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString();
                if (!name.isEmpty()) {
                    namesList.add(name);
                    namesAdapter.notifyDataSetChanged();
                    nameEditText.setText("");
                }
            }
        });

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // implement search functionality here
            }
 });
}
}